'use strict'

module.exports = (value) => {
  return value !== 'bonitaAPI'
}
